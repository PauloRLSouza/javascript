let calcular = () => {

    let f = document.getElementById("grauF").value;
    let c = document.getElementById("grauC").value;

    let q = document.getElementById("quilowatt").value;

    if (f != ""){
        let calculaF = (f - 32) * (5/9) + 273.15;
        document.getElementById("resultado").innerText = f + " °F convertido para Kelvin é " + calculaF.toFixed(2) + " K";

    } else if (c != ""){
        let calculaF = (c) * (9/5) + 32;
        document.getElementById("resultado").innerText = c + " °C convertido para Fahrenheit é " + calculaF.toFixed(1) + " °F";
    } else if (q != ""){
        let calculaQ = q * 0.05;
        document.getElementById("resultado").innerText = q + " Quilowatt-hora multiplicado por 0,05 é " + calculaQ;
    }

}