function calculaIMC() {
  let textos = document.querySelectorAll('input[type="text"]');
  let numeros = document.querySelectorAll('input[type="number"]');
  let genero = document.getElementById("genero").value;

  var ok = false;

  let imc = numeros[0].value / numeros[1].value ** 2;

//   switch(genero){

//   }

  if (imc < 17) {
    let resultado = "Muito abaixo do peso";
  } else if (imc >= 17 && imc <= 18.49) {
    let resultado = "Abaixo do peso";
  } else if (imc >= 18.5 && imc <= 24.99) {
    let resultado = "Peso normal";
  } else if (imc >= 25 && imc <= 29.99) {
    let resultado = "Acima do peso";
  } else if (imc >= 30 && imc <= 34.99) {
    let resultado = "Obesidade I";
  } else if (imc >= 35 && imc <= 39.99) {
    let resultado = "Obesidade II(severa)";
  } else {
    let resultado = "Obesidade III(mórbida)";
  }

  if (ok == true) {
    document.getElementById("mostraNome").innerHTML = textos[0].value;
    document.getElementById("mostraSobrenome").innerHTML = textos[1].value;
    document.getElementById("mostraIMC").innerHTML = imc
      .toFixed(2)
      .replace(".", ",");
    document.getElementById("mostraResultado").innerHTML = resultado;
  }
}
